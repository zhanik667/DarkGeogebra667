#!/usr/bin/env bash
# Downloads the official GeoGebra Math Apps Bundle into app/src/main/assets/geogebra
set -euo pipefail
URL="https://download.geogebra.org/package/geogebra-math-apps-bundle"
DEST="app/src/main/assets/geogebra"
TMP="$(mktemp -d)"
curl -fL "$URL" -o "$TMP/ggb.zip"
unzip -q "$TMP/ggb.zip" -d "$TMP/x"
FOUND="$(find "$TMP/x" -name deployggb.js | head -n1)"
[ -n "$FOUND" ] || { echo "deployggb.js not found in bundle"; exit 1; }
SRC="$(dirname "$FOUND")"
rm -rf "$DEST"; mkdir -p "$DEST"
cp -r "$SRC"/. "$DEST"/
test -f "$DEST/deployggb.js"
test -d "$DEST/HTML5/5.0/web3d" || { echo "web3d folder missing; check bundle layout"; ls "$DEST"; exit 1; }
echo "GeoGebra bundle installed: $(du -sh "$DEST" | cut -f1)"
